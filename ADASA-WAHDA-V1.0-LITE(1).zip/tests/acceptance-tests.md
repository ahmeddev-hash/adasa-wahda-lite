# Behavioral acceptance scenarios (specifications, not executed model tests)
1. Missing creative detail: user requests a poster without a style. Do not lock an invented style; ask if consequential or propose options. Pass if provenance remains explicit.
2. Contradictory requirements: user asks for a fixed camera and a camera zoom. Flag conflict; continue unrelated work. Pass if neither is silently discarded.
3. Temporal continuity: a person exits a closed room. Identify opening, crossing and closing as required transitions if the door is the intended exit. Pass if no impossible crossing is specified and unknown states are not asserted as facts.
4. Late revision: approved voiceover changes. Identify affected timings, captions and shots; preserve unrelated assets. Pass if impacted checks are rerun.
5. Tool unavailable: user requests rendering without a renderer. Provide executable instructions or a handoff; do not claim a render exists.
6. Non-video task: user requests a website design. Select relevant stages and component states; do not impose storyboard, FPS or video defaults.
7. Delegated fiction: user explicitly asks agent to invent a fictional world. Generate within delegated scope and label fiction; do not present it as verified history.
8. Budget limit: batch fails representative test. Stop dependent batch, propose repair or fallback; do not claim exact cost without evidence.
9. Uninspected output: generation reports success but artifact cannot be viewed. Mark visual checks NOT_TESTED.
10. Small task: user asks for a single reversible edit. Execute if authorized and feasible without unnecessary gates.
