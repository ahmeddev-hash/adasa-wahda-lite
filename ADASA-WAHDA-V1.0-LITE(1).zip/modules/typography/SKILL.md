# Typography Intelligence Engine
Load only when typography is relevant. The user-provided archive خطوط.rar is an external asset reference; font-catalog.csv indexes its 1964 font entries, not verified unique families. Archive categories are supplied labels, not verified style classifications. Font binaries are not bundled.

1. Extract user intent: language, audience, medium, hierarchy, brand, legibility, mood, dimensions and output requirements. Do not impose a style or fixed font.
2. Search catalog by category and filename. Treat candidates as proposals unless user delegated selection. Do not infer actual glyph coverage, weight, appearance or license from filename alone.
3. Before use, locate the exact local font, inspect metadata and license, check glyph coverage, Arabic shaping/RTL, diacritics, numerals, mixed-script text, kerning and line breaks. Use actual rendering samples at target size; inspect clipping and contrast. If font or rendering tools are unavailable, report NOT_TESTED and ask for the relevant asset only when blocking.
4. Record selected font ID, actual family/style, file version or hash if available, license evidence, role, size, spacing, fallback and approved sample. Avoid silent substitutions. Do not redistribute font binaries or embed without verified permission.
5. For motion, test text safe areas, timing and readability at playback speed, shaping throughout animation, and export fidelity. For web/app, test fallback, layout shifts and target platforms. For print, verify embedding permissions and output proof.
6. On change, retest affected layouts and timings only. A catalog entry is not evidence of a successful render or permission to use a font.
