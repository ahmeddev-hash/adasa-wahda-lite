# FINAL QC REPORT
Project / build / reviewer / date:

- [ ] Script and visual match; no omitted beats
- [ ] Factual claims and spelling checked
- [ ] Character/prop/location continuity checked
- [ ] No unintended artifacts, morphing or extra people
- [ ] Titles and Arabic RTL shaping legible
- [ ] Correct platform framing and UI-safe text
- [ ] Dialogue/music/SFX synchronized and clean
- [ ] Captions correct and timed
- [ ] Rights, licenses, consent and disclosures documented
- [ ] Correct export settings and file integrity
- [ ] Watched full final render on desktop and mobile
- [ ] User approval captured for requested gates

Defect log: ID | severity | timecode | issue | fix | retest | owner
Decision: PASS / FAIL / UNVERIFIED
Do not mark PASS unless tests were actually performed.
