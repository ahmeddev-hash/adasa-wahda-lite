# Reusable prompts (replace placeholders)

## Beginner intake
"I want a [type] video about [topic]. Ask only the essential missing questions, propose sensible defaults, and guide me one production gate at a time. Explain what I need to do in simple Arabic/English as appropriate."

## Shot image prompt
"Create one [aspect] reference frame for shot [ID]. [subject count and exact description], [location], [time/weather], [shot size, angle, composition], [lighting, palette]. Maintain [locked details]. Exclude [unwanted elements]. Do not render critical Arabic text; leave negative space for editable title overlay."

## Image-to-video prompt
"Animate the supplied reference for [duration]. Preserve exactly [identity, outfit, props, layout, lighting, day/night, geometry]. Only action: [single precise action with start/end]. Camera: [locked/motivated move]. No new subjects, props, dialogue, soundtrack, zoom, morphing or scene transitions unless explicitly requested. Verify [shot-specific pass/fail]."

## Motion graphic prompt
"Build a [duration], [fps], [aspect] motion sequence with [design system]. Layer order: [layers]. Keyframes: [time/property/value]. Easing: [curve]. Typography: [licensed family, exact copy, RTL rules]. Camera: [path]. Hold for readability at [times]. Seamless loop [yes/no and boundary requirements]. Export [spec]."

## Editorial pass
"Review shot [ID] against the approved storyboard and reference. Report PASS/FAIL/UNVERIFIED for identity, action, camera, continuity, text, sound, rights and technical quality. Provide precise defects and minimal fixes; do not claim to have inspected unavailable media."

## Publishing adaptation
"Adapt the approved master for [platform]. Preserve claims and identity, but recut hook, frame, captions, title, thumbnail and CTA to fit the destination. Provide exact deliverables and mark any current platform specification that needs verification."
