# PRODUCTION BRIEF — copy and fill
Project title:
User experience: beginner / intermediate / professional
Video category:
Objective and intended viewer action:
Target audience, language and region:
Primary platform and secondary platforms:
Target duration and aspect ratio:
Creative direction and reference examples:
Existing assets and permissions:
Tools available and limitations:
Budget/deadline:
Facts/claims needing verification:
Accessibility requirements:
Approved decisions / locked assets:
Success criteria:
Unknowns and assumptions:
Next approval gate:
