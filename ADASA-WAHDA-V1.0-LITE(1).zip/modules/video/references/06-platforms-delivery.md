# Platforms, formats and exports

## Format planning
Common starting canvases (verify current platform requirements before final upload): vertical 9:16 at 1080x1920 for short-form; horizontal 16:9 at 1920x1080 or higher for standard YouTube; square 1:1 at 1080x1080 where appropriate; 4:5 at 1080x1350 for some feeds. These are production presets, not guarantees of every platform's current acceptance. Always test crop and UI overlays in the target app.

## Delivery variants
YouTube long-form: searchable title, custom thumbnail, chapters if useful, accurate description, captions, licensed music and a strong first 30 seconds. YouTube Shorts: vertical-first reframing, fast clarity, legible subtitles and a self-contained payoff. Facebook feed/video: hook without relying on audio, readable captions, native aspect ratio and context in post copy. Facebook/Instagram Reels: vertical-first, safe text placement, on-screen hook, captions, pacing and optional cover. TikTok: native vertical pacing and interface-safe text. LinkedIn: business-oriented messaging and subtitles. Ads: platform-specific length, claim substantiation, CTA and policy review. Never promise virality or revenue.

## Export checklist
Document resolution, aspect, FPS, codec, container, bitrate/quality mode, color space, audio codec, channels, caption method and file naming. A common interoperable default is H.264 MP4 with AAC audio, but choose based on actual destination requirements. Preserve frame rate where possible; avoid accidental variable-frame-rate sync problems. Check black frames, frozen frames, banding, clipping, caption cutoffs, compression artifacts and final playback on mobile.

## Repurposing
Re-edit for each platform rather than cropping mechanically. Reposition subject, redesign typography, retime opening and CTA, and inspect audio rights per destination. Create an editable master plus delivery exports and platform-specific covers.

## Publishing package
Working title, final title, thumbnail/poster, description, first comment if needed, tags/hashtags based on relevance, disclosure, credits, sources, subtitle files, alt text where supported and suggested A/B tests. Publication requires explicit user authorization and real access; drafting does not equal publishing.
