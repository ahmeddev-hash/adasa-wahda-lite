# Design systems, Arabic typography, posters and thumbnails

## Typography selection, not a universal font mandate
Choose licensed fonts based on genre, readability, available glyphs, shaping support and target medium. Font availability and commercial licenses must be verified. Arabic candidates (examples, not exhaustive): Cairo, Tajawal, Almarai, IBM Plex Sans Arabic, Noto Sans Arabic, Noto Kufi Arabic, Noto Naskh Arabic, Amiri, Aref Ruqaa, Reem Kufi, Changa, El Messiri, Markazi Text, Lateef, Scheherazade New, Readex Pro, Alexandria, Baloo Bhaijaan 2, Lemonada, Mada, Harmattan, Katibeh, Rakkas, Kufam. Some suit body text, others display only; check actual family/style licensing and language coverage.

## Genre mapping
Horror/thriller: strong high-contrast display lettering, distressed textures sparingly, dark red/ivory accents, generous negative space; test Rakkas, Aref Ruqaa, Katibeh or custom lettering for headlines, paired with readable Cairo/Tajawal/Noto Sans Arabic for secondary text. Historical: Amiri, Noto Naskh Arabic, Scheherazade New. Technology: IBM Plex Sans Arabic, Tajawal, Cairo, Alexandria. Educational: Cairo, Almarai, Noto Sans Arabic, Readex Pro. Luxury/editorial: carefully paired Naskh/Kufi families. Comedy/youth: Changa, Baloo Bhaijaan 2, Lemonada if tone fits. Never imply any font is inherently 'the horror font'; test the actual title.

## Arabic typesetting rules
Use correct RTL shaping, connected letterforms, ligatures where appropriate, diacritics only when useful, Arabic punctuation, balanced line breaks, numerals per audience, and no manual letter spacing that breaks joins. Check hamza, ta marbuta, alef maqsura and local names. For English/Arabic mixed text, inspect bidirectional ordering. Do not generate critical title text inside an AI image when exact spelling is required: overlay editable text in post.

## Poster and thumbnail composition
One dominant focal point; legible 3–7 word headline where appropriate; clear genre cue; hierarchy of title/subtitle/credit; adequate contrast; no clutter; preserve face/product; test at phone thumbnail size. Create platform-specific crops rather than stretching. Posters can be vertical, horizontal or square depending on destination. Keep key copy away from UI overlays; platform safe areas vary and must be checked against current preview.

## Design handoff
Supply font family, fallback, licensed source, weights, sizes in relative hierarchy, tracking/leading where applicable, palette HEX, overlay opacity, shadow/glow limits, safe-area guides, logo clearance and editable layer naming. Never distribute paid fonts or assume all are free.
