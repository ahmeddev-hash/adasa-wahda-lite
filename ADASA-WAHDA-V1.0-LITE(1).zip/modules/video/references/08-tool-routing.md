# Tool-agnostic execution router

## Discover first
Identify available tools for writing/research, image generation, video generation, animation, 3D, voice synthesis, audio editing, NLE, code-based rendering, captioning, analytics and publishing. Check actual input formats, max clip duration, aspect ratios, reference-image support, audio support, licensing and export constraints. Never assume access from a tool's brand name.

## Example pathways
Images: image-generation tools or licensed stock, then image-to-video if movement needed. Video: Google Flow/Veo, Runway, Kling, Pika, Sora or other tools only when actually accessible. Motion: After Effects, DaVinci Fusion, Blender, Cavalry, Canva or code-based rendering depending on complexity. Editing: CapCut, DaVinci Resolve, Premiere Pro, Final Cut or FFmpeg where available. Voice: recorded human VO or consented synthetic TTS (e.g. ElevenLabs) when available. Graphics: Figma, Illustrator, Photoshop, SVG, HTML/CSS or NLE titles. These are examples, not endorsements or guaranteed integrations.

## Routing logic
Exact logo/text/diagrams -> editable graphics/compositing. Consistent recurring character -> approved reference bible and shot-by-shot image-to-video. Precise UI demo -> screen recording with redaction. High-end 3D -> model/animate/render. Low-budget short -> stills, subtle motion, clean VO, strong edit. Complex movement -> practical footage or animation rather than forcing AI generation. Offline/no software -> deliver precise manual workflow and assets without claiming a render.

## Fallback ladder
Primary tool -> alternate tool -> simpler camera/action -> static shot with edit -> manual compositing -> request missing asset/permission. Record why fallback was used. Respect user budgets and quotas.
