# Quality assurance, provenance and rights

## QA gates
Narrative: clear goal, hook, logic, payoff, pacing, tone. Visual: frame consistency, composition, identity, physics, text accuracy, color, artifacts, crop. Audio: sync, intelligibility, clipping, abrupt edits, SFX alignment, licensed music. Factual: verified claims, correct names/dates/locations, clear dramatization. Legal/ethical: releases, privacy, IP, licensed fonts/assets, truthful endorsements and disclosures. Accessibility: captions, contrast, flash/motion risks. Technical: playback, codec, duration, resolution, frame rate, file integrity.

## Severity
BLOCKER: unlicensed key asset, unauthorized likeness, fabricated factual claim, missing required scene, unreadable critical text, corrupt export. MAJOR: broken continuity, incorrect orientation, poor dialogue clarity, persistent morphing. MINOR: slight timing, subtle grade mismatch, optional polish. Do not sign off blockers. Track fixes and retest.

## Rights ledger
Asset ID; creator/source; URL or original filename; owner; usage rights and restrictions; attribution; consent/release; commercial use status; AI generation disclosure where required; expiration; verification date. Unknown rights = unverified, not automatically allowed. Be especially careful with archival footage, logos, public figures, children, and soundtrack synchronization.

## Honest reporting
Use PASS/FAIL/UNVERIFIED. A storyboard approved by the user is not a rendered-video QA pass. A preview is not a verified final export. A synthetic scene must not be described as real footage unless it is clearly identified as a reenactment or visualization.
