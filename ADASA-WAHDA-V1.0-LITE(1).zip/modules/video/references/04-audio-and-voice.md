# Audio, voice, music and accessibility

## Voice pipeline
Prepare narration with punctuation and pauses; specify language, dialect, persona, pace, emotion and pronunciation dictionary. Keep written names canonical; add separate phonetic/TTS variants only where necessary. Generate short test clips for names and difficult words before full render. Do not clone a real person's voice without authorization. Record room tone and a clean pickup track where possible.

## Sound design
Separate dialogue, narration, ambience, Foley, transitions, effects and music into distinct tracks. Build a sound map per shot; use silence intentionally. Ensure effects correspond to visible actions and spatial perspective. Avoid generic constant horror drones or sound effects that contradict the setting. License all samples and music.

## Mixing and mastering
Prioritize intelligible speech, control peaks, remove noise conservatively, use EQ/compression/de-essing only as needed, duck music under dialogue and test on phone speakers/headphones. Follow current platform loudness and true-peak specifications when known; never assume one number applies everywhere. Deliver clean master and optional stems.

## Captions
Provide accurate, synchronized captions, correct Arabic spelling and punctuation, appropriate line breaks, sufficient contrast and platform-safe positioning. Include relevant non-speech audio for accessibility when needed. Offer SRT/VTT and burned-in versions as requested. For RTL captions test mixed numerals and English names. Avoid flashing and excessively rapid typography.
