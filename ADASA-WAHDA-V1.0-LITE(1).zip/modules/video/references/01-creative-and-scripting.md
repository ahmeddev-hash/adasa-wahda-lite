# Creative development, writing and research

## Video structures
Short-form: hook (0–2s as a starting heuristic, not universal), context, escalating value, payoff, CTA if needed. Long-form: cold open, promise, chapters, evidence/examples, midpoint turn, payoff, recap and next step. Narrative: setup, inciting incident, rising action, reversal, climax, resolution. Tutorial: problem, prerequisites, demo, troubleshooting, recap. Ad: audience problem, differentiated solution, credible proof, clear offer, CTA. Documentary: research question, sourced context, competing interpretations where relevant, verified conclusion or honest uncertainty.

## Script formats
Create a two-column AUDIO/VISUAL timed script and beat sheet. Specify exact on-screen wording and voiceover separately. Estimate duration using approximate spoken words per minute appropriate to language, delivery and pauses; verify with an actual recording. In Arabic, write natural dialect when requested, and separate display spelling from TTS pronunciation. Avoid repetitive exposition and redundant shots.

## Research ledger
For each material claim: claim ID, exact assertion, source URL/document, date checked, confidence, on-screen treatment and licensing status. For fictionalized stories distinguish folklore, witness recollection, reconstruction and verified facts. Never invent quotations or present a reenactment as archival footage.

## Storytelling QC
Does every 5–15 second span advance information, emotion or action? Are stakes and visual causality clear? Is the opening relevant rather than clickbait? Are character motives coherent? Are titles and claims accurate? Is the payoff delivered? Adapt pacing to genre, not a fixed formula.
