# Cinematography, composition and continuity

## Shot sizes and camera grammar
Extreme wide (geography/scale), wide (blocking), medium (action/conversation), medium close-up (performance), close-up (emotion/detail), extreme close-up (critical object), insert (evidence/prop), POV (subjective perspective), over-shoulder (relationship), top-down (process/map), tracking (movement), static locked-off (clarity/tension). Camera height and angle convey perspective; use motivated movement, not constant motion.

## Framing
Rule of thirds, center symmetry, leading lines, depth layers, foreground occlusion, headroom, look room, negative space for titles, 180-degree axis, screen direction, eyeline match and action match. Preserve subject visibility in mobile crops. Use depth of field purposefully; avoid unreadable important objects.

## Light and color
Record time of day, key-light direction, color temperature, shadow behavior, practical lights, contrast ratio, atmosphere and grade references. Avoid day/night, weather or season changes between adjacent shots without story reason. Match skin tones and product colors. Maintain an approved palette but permit intentional dramatic changes.

## Continuity bible
Character ID and approved reference images; age range/appearance where supplied; wardrobe; hairstyle; accessories; posture; prop inventory; location floor plan; fixed landmarks; action state; entrances/exits; left-right orientation; weather; lighting; sound ambience; timeline. Each shot must identify what is locked vs intentionally changing. Do not infer identities or characteristics not given.

## Shot-sheet columns
ID, scene, start/end time, objective, frame size, angle, lens feel (not fabricated camera metadata), blocking, action, camera motion, lighting, reference, on-screen text, VO, SFX, transition, continuity locks, failure modes, QC status.

## Live action safety
Secure location access, release forms, safe rigs, practical effects supervision, drone permits where applicable, weather contingency and backup audio. Never propose dangerous stunts without trained crew and safety planning.
