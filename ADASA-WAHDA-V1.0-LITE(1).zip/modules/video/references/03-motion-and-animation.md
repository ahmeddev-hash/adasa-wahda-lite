# Motion graphics, 2D/3D and AI video

## Motion design
Use visual hierarchy, clear information architecture, restrained motion language and deliberate rhythm. Define 2D/2.5D/3D treatment, grid, anchor points, parent-child transforms, parallax layers, masks, matte logic, z-depth, easing curves, overshoot limits, motion blur, transitions and loop seams. Prefer a few coordinated motions over arbitrary animation. Use hold frames for comprehension. Check motion-reduced alternatives where appropriate.

## Animation timing
Specify frame rate, duration, beat markers, keyframes, hold intervals and easing in a timeline. Use timing charts rather than vague 'smooth'. When looping, match initial/final positions, velocity and visual state. Avoid unmotivated camera zooms and whip pans. For infinite zoom, plan nested compositions, image resolution, perspective, camera trajectory, transition overlap and loop boundary.

## 3D workflow
Concept -> references -> modeling -> UV/materials -> rigging (if needed) -> layout -> lighting -> animation -> simulation (if needed) -> render passes -> compositing -> grade -> QC. Track polygon/render constraints, texture licenses, color management, denoising and output alpha.

## AI video generation
Choose text-to-video for unconstrained concepts, image-to-video for strict composition/identity, video-to-video for controlled transformations, manual compositing for exact logos/typography/geometry. Generate one shot at a time, with a source frame and expected final frame if supported. Ask for small, physically plausible movements; protect scene identity and prop counts. Avoid letting a generator redraw critical text; composite final typography in an editor. If source footage contains people, obtain necessary consent for synthetic alteration.

## Common failure diagnostics
Morphing hands/faces -> reduce action, use closer reference and shorter shot. Vanishing props -> freeze/track prop or composite. Subject walking through wall -> redefine path/blocking. Camera zoom when prohibited -> lock camera explicitly, choose static frame fallback. Text corruption -> remove generated text and add in post. Lighting flips -> specify unchanged key direction. Extra people -> explicitly state exact count and crop.

## Scene prompt schema
Shot ID; source asset; duration/aspect; exact subject count; setting and time; action start/end; fixed camera vs specified move; composition; light; continuity; negative constraints; intended audio (usually none for silent generation); pass/fail checks.
