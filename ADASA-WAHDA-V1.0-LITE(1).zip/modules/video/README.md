# عدسة واحدة | Adasa Wahda Video Production Skill v2.1
A reusable, platform-agnostic production system for any AI agent or human producer.

## Install
Upload the complete folder/ZIP to an agent that supports skills or project knowledge. If it supports skill discovery, point it to `SKILL.md`; keep `references/` and `templates/` in the same directory. If it cannot install skills, attach the folder contents as project knowledge and instruct it to follow `SKILL.md` first. Do not assume the agent can execute renders, access external tools or persist files.

## Starter request
"Use the adasa-wahda-video-production skill. I am a beginner and want a 45-second vertical explainer about [topic] for Instagram Reels. Choose sensible defaults, ask only essential questions, and stop at each approval gate."

## What it is not
It is not a renderer, editing program, guaranteed model-control mechanism, source of licensed assets or substitute for human quality review. It defines a repeatable workflow and acceptance tests.
