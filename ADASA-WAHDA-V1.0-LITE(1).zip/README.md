# عدسة واحدة V1.0 Lite
Portable AI governance skill + optional Python structural validator. Start with SKILL.md, CORE.md, ACTIVATION.md and PORTABILITY.md. Created & Developed by Ahmed Khaled — © 2026 ADASA WAHDA. Previous video and typography modules retained. Reference snapshots indexed in references/manifest.json; original archives remain external. No fonts or third-party code bundled. Run `python runtime/test_validate.py` and `python runtime/validate.py templates/project.json`. This is not a native extension and does not guarantee model compliance. See audit.txt for actual test results.

## Official release / الإصدار الرسمي

ADASA WAHDA V1.0 — Lite

Free edition — النسخة المجانية.

صاحب عدسة واحدة: أحمد خالد — © 2026 ADASA WAHDA — جميع الحقوق محفوظة للمحتوى الأصلي.
