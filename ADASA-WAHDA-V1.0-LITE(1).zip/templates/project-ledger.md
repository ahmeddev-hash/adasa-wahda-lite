# Project ledger | سجل المشروع
- Project ID / baseline version / owner:
- User's original brief:
- Deliverables / deadline / budget / delegated scope:

## Requirements
| ID | Requirement | Source | Status | Locked? | Acceptance test |
|---|---|---|---|---|---|

## Units and dependencies
| Unit ID | Inputs / dependencies | Initial state | Action | End state | Invariants | Duration estimate | Status |
|---|---|---|---|---|---|---|---|

## Risks
| ID | Unit | Failure / cause | Severity | Detection | Mitigation | Fallback |
|---|---|---|---|---|---|---|

## Change log
| Version | Requested delta | Affected IDs | Time/cost impact | Approval | Retests |
|---|---|---|---|---|---|

## Verification
| Test ID | Requirement ID | Artifact/version | Method | Evidence | Result |
|---|---|---|---|---|---|

## Handoff
Actual deliverables, unresolved items, limitations, rights, next steps.
