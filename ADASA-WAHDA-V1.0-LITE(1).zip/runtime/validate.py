import json,sys

def validate(p):
    errors=[]
    rs=p['requirements']; us=p['units']; r={x['id']:x for x in rs}; u={x['id']:x for x in us}
    if len(r)!=len(rs) or len(u)!=len(us): errors.append('duplicate IDs')
    for x in rs:
        if x['status'] not in ('CONFIRMED','DERIVED','PROPOSED','UNKNOWN','CONFLICT'): errors.append('invalid requirement status')
        if x['status'] in ('CONFIRMED','DERIVED') and not x.get('source'): errors.append('missing provenance '+x['id'])
    visiting=set(); done=set()
    def visit(k):
        if k in visiting: errors.append('dependency cycle '+k); return
        if k in done: return
        visiting.add(k)
        for d in u[k].get('depends_on',[]):
            if d not in u: errors.append('missing dependency '+d)
            else: visit(d)
        visiting.remove(k);done.add(k)
    for k,x in u.items():
        visit(k)
        for q in x.get('requires',[]):
            if q not in r or r[q]['status'] not in ('CONFIRMED','DERIVED'): errors.append('unapproved requirement '+q)
        if 'start' in x or 'end' in x:
            if not isinstance(x.get('start'),(int,float)) or not isinstance(x.get('end'),(int,float)) or not 0<=x['start']<x['end']: errors.append('invalid timing '+k)
        for d in x.get('depends_on',[]):
            if d in u and 'end' in u[d] and 'start' in x and u[d]['end']>x['start']: errors.append('dependency timing '+k)
        for c in x.get('checks',[]):
            if c['status'] in ('PASS','WAIVED') and not c.get('evidence'): errors.append('missing test evidence '+k)
    return errors
if __name__=='__main__':
    try: errors=validate(json.load(open(sys.argv[1],encoding='utf8')))
    except (KeyError,TypeError,ValueError,OSError,IndexError) as e: errors=['invalid ledger: '+str(e)]
    print(json.dumps({'structural_status':'FAIL' if errors else 'PASS','errors':errors},ensure_ascii=False));sys.exit(bool(errors))
