import unittest,copy,json,pathlib
from validate import validate
class Tests(unittest.TestCase):
 def setUp(self): self.p=json.loads((pathlib.Path(__file__).parent.parent/'templates/project.json').read_text())
 def test_valid(self): self.assertFalse(validate(self.p))
 def test_unknown(self): self.p['requirements'][0]['status']='UNKNOWN';self.assertTrue(validate(self.p))
 def test_cycle(self): self.p['units'][0]['depends_on']=['U1'];self.assertTrue(validate(self.p))
 def test_missing(self): self.p['units'][0]['depends_on']=['U9'];self.assertTrue(validate(self.p))
 def test_timing(self): self.p['units'][0]['end']=-1;self.assertTrue(validate(self.p))
 def test_evidence(self): self.p['units'][0]['checks'][0]['status']='PASS';self.assertTrue(validate(self.p))
 def test_duplicate(self): self.p['units'].append(copy.deepcopy(self.p['units'][0]));self.assertTrue(validate(self.p))
 def test_provenance(self): self.p['requirements'][0]['source']='';self.assertTrue(validate(self.p))
if __name__=='__main__': unittest.main()
